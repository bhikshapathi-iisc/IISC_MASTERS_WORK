#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <input_file> <num_threads>\n", argv[0]);
        return 1;
    }

    // Read the number of threads from the command line
    int num_threads = atoi(argv[2]);
    if (num_threads <= 0) {
        printf("Invalid number of threads: %d\n", num_threads);
        return 1;
    }

    // Open the input file
    FILE *file = fopen(argv[1], "r");
    if (!file) {
        perror("Error opening file");
        return 1;
    }

    // Read the array size
    int n;
    fscanf(file, "%d", &n);

    // Allocate memory for the arrays
    long long int *A = (long long int *)malloc(n * sizeof(long long int));
    long long int *B = (long long int *)malloc(n * sizeof(long long int));

    if (!A || !B) {
        printf("Memory allocation failed\n");
        fclose(file);
        return 1;
    }

    // Read the array elements
    for (int i = 0; i < n; i++) {
        fscanf(file, "%lld", &A[i]);
    }
    fclose(file);

    // Allocate memory for offsets
    long long int *offsets = (long long int *)malloc(num_threads * sizeof(long long int));
    if (!offsets) {
        printf("Memory allocation for offsets failed\n");
        free(A);
        free(B);
        return 1;
    }

    double start_time = omp_get_wtime();

    omp_set_num_threads(num_threads);

    #pragma omp parallel
    {
        int tid = omp_get_thread_num();
        int chunk_size = n / num_threads;
        int start = tid * chunk_size;
        int end = (tid == num_threads - 1) ? n : start + chunk_size;

        // Step 1: Compute local prefix sums
        B[start] = A[start];
        for (int i = start + 1; i < end; i++) {
            B[i] = B[i - 1] + A[i];
        }

        // Step 2: Store the last value of the local prefix sum as the offset
        #pragma omp critical
        {
            offsets[tid] = B[end - 1];
        }

        #pragma omp barrier

        // Step 3: Compute cumulative offsets sequentially by thread 0
        if (tid == 0) {
            for (int i = 1; i < num_threads; i++) {
                offsets[i] += offsets[i - 1];
            }
        }

        #pragma omp barrier

        // Step 4: Adjust prefix sums using offsets
        if (tid > 0) {
            for (int i = start; i < end; i++) {
                B[i] += offsets[tid - 1];
            }
        }
    }

    double end_time = omp_get_wtime();

    // Print execution time
    printf("Execution Time with %d threads: %f seconds\n", num_threads, end_time - start_time);

    // Print the last element of the result array (final sum)


    // Free allocated memory
    free(A);
    free(B);
    free(offsets);

    return 0;
}


