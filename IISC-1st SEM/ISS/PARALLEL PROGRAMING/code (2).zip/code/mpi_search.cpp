// mpi_search.cpp
#include <cstddef>    // Ensures ptrdiff_t is defined
#include <mpi.h>
#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
 
int main(int argc, char *argv[]) {
    MPI_Init(&argc, &argv);
 
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
 
    const int n = 1000000;  // Size of the array
    std::vector<int> data(n,0);
 
    // Seed random generator
    srand(time(NULL) + rank);
 
    // Generate data only on the root process
    if (rank == 0) {
        for (int i = 0; i < n; ++i) {
            data[i] = rand() % 5000000 + 1;  // Random numbers between 1 and 5000000
        }
    }
 
    // Determine the size of each subarray
    int local_n = n / size;
 
    // Allocate memory for local data
    std::vector<int> local_data(local_n);
 
    // Scatter the data to all processes
    MPI_Scatter(data.data(), local_n, MPI_INT, local_data.data(), local_n, MPI_INT, 0, MPI_COMM_WORLD);
 
    // Check for correct number of command line arguments
    if (argc != 2) {
        if (rank == 0) {
            std::cerr << "Usage: " << argv[0] << " <number_to_find>" << std::endl;
        }
        MPI_Finalize();
        return 1;
    }
 
    int to_find = atoi(argv[1]);
    int found = 0;
    int global_idx = n;  // Initialize to 'n' to indicate not found
    int stop_signal = 0;
 
    // Start timing after data distribution
    double start_time = MPI_Wtime();
 
    // Setup a non-blocking receive for the stop signal
    MPI_Request stop_request;
    MPI_Irecv(&stop_signal, 1, MPI_INT, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &stop_request);
 
    // Each process searches in its part of the array
    for (int i = 0; i < local_n && !stop_signal; ++i) {
        if (local_data[i] == to_find) {
            found = 1;
            global_idx = rank * local_n + i;
            // Send a stop signal to all other processes
            for (int p = 0; p < size; ++p) {
                if (p != rank) {
                    MPI_Send(&found, 1, MPI_INT, p, 0, MPI_COMM_WORLD);
                }
            }
            break;
        }
        // Check periodically if a stop signal was received
        int flag;
        MPI_Test(&stop_request, &flag, MPI_STATUS_IGNORE);
        if (flag) break;
    }
 
    // Ensure all processes reach this point before reducing
    MPI_Barrier(MPI_COMM_WORLD);
 
    // Reduce to get the smallest index (i.e., first found)
    MPI_Reduce(&global_idx, &global_idx, 1, MPI_INT, MPI_MIN, 0, MPI_COMM_WORLD);
 
    // Stop timing after all computation is finished
    double end_time = MPI_Wtime();
    double exec_time = end_time - start_time;
 
    if (rank == 0) {
        if (global_idx < n) {
            std::cout << "Element found at index " << global_idx << std::endl;
        } else {
            std::cout << "Element not found." << std::endl;
        }
        // Print execution time in a consistent format
        printf("Execution Time: %.6f seconds\n", exec_time);
    }
 
    MPI_Finalize();
    return 0;
}